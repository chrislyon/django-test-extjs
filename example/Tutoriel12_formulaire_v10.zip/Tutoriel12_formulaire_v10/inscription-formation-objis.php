<?php

Echo '{
			success: false,
			 errors: {theme: "Nous ne formons pas sur cette techno"},
		   errormsg: "Desole ce theme de formation ne figure pas dans notre catalogue"
	}' ;
?>