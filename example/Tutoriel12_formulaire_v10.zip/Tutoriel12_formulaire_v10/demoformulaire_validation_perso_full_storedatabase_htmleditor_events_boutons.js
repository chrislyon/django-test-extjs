function creationformulaire() {
    Ext.QuickTips.init();
	Ext.apply(Ext.form.VTypes, {
		themeVal: /^[A-Z][A-Za-z]+$/,
		themeMask: /[A-Za-z ]/,
		themeText: 'Nom de formation incorrect.',
		theme: function(v) {
		return this.themeVal.test(v);
		}
	});
	
	// Donn�es de la combo en m�moire
		var financements2 = new Ext.data.SimpleStore({
				fields: ['id', 'type_financement'],
				data : [
					['0','Autre...'],
					['1','Entreprise'],
					['2','Personnel']
					]
				});


	// Donn�es de la combo cot� serveur
	var financements = new Ext.data.JsonStore({
   
    autoDestroy: true,
	
    storeId: 'myStore',
	
    proxy: {                            // ou sont les donn�es ?
        type: 'ajax',
        url: 'script-financement.php',  // cot� serveur, via script PHP
        reader: {
            type: 'json',               // format fichier : JSON
            root: 'enregistrements',    // D�but des donn�es
            idProperty: 'id'            // cl� primaire
        }
    },

    fields: ['id', 'type_financement'] 
});

			financements.load();   // Chargement des donn�es avant que l'utilisateur ne pui interragir.


	
	var demoformulaire = new Ext.FormPanel({
		 url: 'inscription-formation-objis.php',
	renderTo: Ext.getBody(),
       frame: true,
       title: 'Inscription formation Objis',
       width: 270,
	   items: [{
			xtype: 'textfield',
	   fieldLabel: 'Th�me',
             name: 'theme',
	   allowBlank: false,
			vtype: 'theme',
			listeners :{
			specialkey: function(field, eventObj){
						if (eventObj.getKey() == Ext.EventObject.ENTER) {
						//demoformulaire.getForm().submit();
						Ext.Msg.alert('appui btn entree');
							}
						}
				}
			},{
			xtype: 'textfield',
	   fieldLabel: 'Lieu',
			 name: 'lieu'
			},{
			xtype: 'datefield',
	   fieldLabel: 'Date',
			 name: 'date'
			},{
			xtype: 'radiogroup',
		  columns: 1,
       fieldLabel: 'Niveau',
             name: 'niveau',
            items: [{
				name: 'niveau',
            boxLabel: 'D�butant',
          inputValue: 'debutant'
                  },{
               name: 'niveau',
           boxLabel: 'Avance',
         inputValue: 'avance'
                }]
            },{
			xtype: 'checkbox',
	   fieldLabel: 'Club Objis',
	         name: 'clubobjis'
			},{
			xtype: 'combo',
	   hiddenName: 'financement',
       fieldLabel: 'Financement',
             mode: 'remote',
            store: financements,               // financement venant ou non de la base de donn�es
     displayField:'type_financement',
       valueField:'id',
			listeners: {
				select: function(combo, records, options){ // Nombre de parametres tir� de l'API events/select
				//console.log(records[0].data.id);         // Bonne pratique pour logs durant phase de dev
						if (records[0].data.id==0){        // Aucun financement 
							Ext.Msg.prompt('Autre financement', 'Type', Ext.emptyFn);
							}
						else {Ext.Msg.alert('Financement choisit : ', 'index N� '+records[0].data.id);}
					}
			}
           },{
			xtype: 'htmleditor',
			 name: 'description',
		hideLabel: true,              // Pas de colonne Label � gauche
		   height: 100,               
	       anchor: '100%'             // Vient de la clase 'Container'. Taux d'occupation de la zone
			}
			],
		    buttons: [{               // Boutons pour validation formulaire & Reset
				text: 'Envoyer',
			 handler: function(){
					demoformulaire.getForm().submit({
						success: function(form, action){
									Ext.Msg.alert('Success', '�a marche !');
								},
						failure: function(form, action){
									if (action.failureType == Ext.form.Action.CLIENT_INVALID) {
								Ext.Msg.alert("Ne peut soumettre", "Certains champs sont invalides");
									} else if (action.failureType === Ext.form.Action.CONNECT_FAILURE) {
								Ext.Msg.alert('Echec', 'Pb de connection au serveur: '+a.response.status+' '+a.response.statusText);
									} else if (action.failureType === Ext.form.Action.SERVER_INVALID) {
								Ext.Msg.alert('Attention', action.result.errormsg);
									}
								}
							});
						}
					}, {
				text: 'Reset',
			 handler: function(){
					demoformulaire.getForm().reset();
					}
				}]			
		});
		
		
		// Chargement statique 
		//demoformulaire.getForm().findField('theme').setValue('ExtJS');
		
		// Chargement dynamique 
		demoformulaire.getForm().load({url:'data/formation.php',params:{id: 1}});

		
		}

Ext.onReady(creationformulaire);                                                                      