<?php

// connection serveur DB
$link = mysql_connect("localhost", "root", "")
    or die("Impossible de se connecter : " . mysql_error());
	
// choix base 
mysql_select_db('formationextjs', $link);

$sql = "SELECT * FROM formation WHERE id = ".$_REQUEST['id'];

If (!$rs = mysql_query($sql)) {

	Echo '{success: false}';

}else{

    If (mysql_num_rows($rs) > 0) {
    	$obj = mysql_fetch_object($rs);
    	Echo '{success: true, data:'.json_encode($obj).'}';
    }else{
    	Echo '{success: false}';
    }

}

?>
