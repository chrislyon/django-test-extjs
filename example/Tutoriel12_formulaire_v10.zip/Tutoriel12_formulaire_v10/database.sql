-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- G�n�r� le : Ven 27 Mai 2011 � 06:05
-- Version du serveur: 5.1.36
-- Version de PHP: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Base de donn�es: `formationextjs`
--

-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `financements` (
  `id` int(11) NOT NULL,
  `type_financement` varchar(20) NOT NULL,
  `description` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `financements`
--

INSERT INTO `financements` (`id`, `type_financement`, `description`) VALUES
(0, 'Aucun', ''),
(1, 'Entreprise', ''),
(2, 'Personnel', '');


--
-- Structure de la table `formation`
--

CREATE TABLE IF NOT EXISTS `formation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `theme` varchar(20) NOT NULL,
  `date` varchar(20) NOT NULL,
  `lieu` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `formation`
--

INSERT INTO `formation` (`id`, `theme`, `date`, `lieu`) VALUES
(1, 'ExtJS', '06/02/2012', 'Paris');
