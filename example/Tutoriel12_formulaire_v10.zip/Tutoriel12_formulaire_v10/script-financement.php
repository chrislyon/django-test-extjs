<?php

// connection serveur DB
$link = mysql_connect("localhost", "root", "")
    or die("Impossible de se connecter : " . mysql_error());
	
// choix base 
mysql_select_db('formationextjs', $link);

// requete sql
$result = mysql_query('SELECT id, type_financement FROM financements');

// boucle sur enregistrements
If (mysql_num_rows($result) > 0) {
	while ($obj = mysql_fetch_object($result)) {
		$arr[] = $obj;
	}
}

// Transformation flux JSON
Echo '{enregistrements:'.json_encode($arr).'}';

//Fermeture connexion DB
mysql_close($link);
?>
