function creationformulaire() {
	new Ext.FormPanel({
		 url: 'inscription-formation-objis.php',
	renderTo: Ext.getBody(),
       frame: true,
       title: 'Inscription formation Objis',
       width: 250,
	   items: [{
			xtype: 'textfield',
	   fieldLabel: 'Th�me',
             name: 'theme'
			},{
			xtype: 'textfield',
	   fieldLabel: 'Lieu',
			 name: 'lieu'
			},{
			xtype: 'datefield',
	   fieldLabel: 'Date',
			 name: 'date'
			}]
		});
		}

Ext.onReady(creationformulaire);                                                                      